public class Musica extends ServiceCommunicator{

    public Musica (String musica) {
        super("https://itunes.apple.com/search?term=BEYONCE&limit=1" + musica);
    }

}
